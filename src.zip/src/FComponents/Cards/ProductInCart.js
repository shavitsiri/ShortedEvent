import * as React from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';


export default function ProductInCart(props) {
  return (
    <Card sx={{ maxWidth: 345 ,padding:'25px', margin:'30px'}}>
      <CardMedia
        component="img"
        alt={props.name}
        height="140"
        image={props.img}
      />
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          {props.name}
        </Typography>
        <Typography variant="body2" color="text.secondary">
             
          <b>Serial Number :</b> {props.id} <br/>
          {props.desc} <br/>
          <b>price:</b> {props.price} ₪
        </Typography>
      </CardContent>
      <CardActions>
        <select>
          <option label='1' value='1' ></option>
          <option label='2' value='2' ></option>
          <option label='3' value='3' ></option>
          <option label='4' value='4' ></option>
          <option label='5' value='5' ></option>
        </select>
        </CardActions>
        
      <button onClick={() => props.deleteFromCart(props.id)}  style={{backgroundColor:'#03A586', cursor:'pointer',border:'2px solid black', borderRadius:'28px', padding:'9px 12px'}}>Delete</button>
      
    </Card>
  );
}
