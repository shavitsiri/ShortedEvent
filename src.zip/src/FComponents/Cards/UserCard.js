import * as React from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';

export default function UserCard(props) {
  return (
    <Card sx={{  height:'60vh', width:'45%', textAlign:'center' }}>
      <CardContent>
        <Typography style={{ fontFamily:'cursive',fontSize:'40px'}} gutterBottom  component="div">
        <u><b>Your Profile Details</b></u>
        </Typography>
        <Typography style={{ fontFamily:'cursive',fontSize:'30px',fontStyle:'oblique',color:'#C34969'}} variant="body2" color="text.secondary">
                <u>First Name</u>: {props.firstName} <br /> 
                <u>Last Name</u>:  {props.lastName} <br /> 
                <u>userName</u>: {props.userName} <br /> 
                <u>Email</u>: {props.email} <br /> 
                <u>Country</u>: {props.country} <br /> 
                <u>City</u>: {props.city} <br /> 
                <u>Street</u>: {props.street} <br />
                <u>House Number</u>: {props.houseNumber}
        </Typography>
      </CardContent>
      <br/>
      <button style={{backgroundColor:'#03A586', cursor:'pointer',border:'2px solid black', borderRadius:'28px', padding:'9px 12px'}}>Update Details</button>

    </Card>
  );
}
