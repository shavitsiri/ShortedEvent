import React from "react";
import {
Box,
Container,
Row,
Column,
FooterLink,
Heading,
} from "./FooterStyles";




const Footer = () => {
return (
	<Box>

	<Container>
		<Row>
		<Column>
        
			<Heading>All rights reserved to Shavit && Erez</Heading>
			{/* <FooterLink href="#">Aim</FooterLink> */}
			
		</Column>
		{/* <Column>
			<Heading>Services</Heading>

			
		</Column> */}
       <a  href="#">go top</a>
       
      
      
      
    
		
		
		</Row>
	</Container>
	</Box>
);
};
export default Footer;
