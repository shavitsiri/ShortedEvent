import React from 'react';
import { useEffect,useState } from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import { useNavigate } from 'react-router-dom';

export default function Contact() {

    const [name, setName] = useState('');
    const handleChange = (event) => {
    setName(event.target.value);
    }

    const [email, setEmail] = useState('');
    const [subject, setSubject] = useState('');
    const [message, setMessage] = useState('');

    const sendEmail = () => {
    }

    return (
        <div style={{textAlign:'center', height:'85vh'}}>
               <br/>
               <label style={{fontFamily:'Cursive', fontSize:'35px',color:'white'}}> <b><u>ContactUs Page</u></b></label>

            <Box component="form" sx={{ '& > :not(style)': { m: 1, width: '25ch' },}} noValidate autoComplete="off"
                    bgcolor={'lightblue'} marginTop={'30px'} width={'50%'} marginLeft={'25%'} >

                    <TextField id="outlined-name" label="Email" style={{width:'45%'}}
                        onClick={handleChange} onChange={e => setEmail(e.target.value)} />

                    <br/>

                    <TextField id="outlined-uncontrolled" label="Subject" style={{width:'45%'}}
                        onChange={e => setSubject(e.target.value)} />

                    <br/>

                    <TextField id="outlined-uncontrolled" label="Message" style={{width:'45%'}}
                        onChange={e => setMessage(e.target.value)} />

                    <br/>

                    <button onClick={sendEmail} style={{marginTop:'30px',backgroundColor:'#03A586', cursor:'pointer',border:'2px solid black', borderRadius:'28px', padding:'9px 12px'}}><b>Send</b></button>

            </Box>
        </div>
    )
}
