import React, { useMemo } from 'react';
import { useEffect,useState } from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import { useNavigate } from 'react-router-dom';
import { MenuItem } from '@mui/material';
import * as Valid  from '../utils/Valid.jsx'


export default function SignUp() {

    const optionsCountry = [
        {
          value: "Usa",
          label: "Usa"
        },
        {
          value: "England",
          label: "England"
        },
        {
          value: "Israel",
          label: "Israel"
        },
        {
          value: "Japan",
          label: "Japan"
        }
      ];

    const customStyles = {
        option: (provided, state) => ({
          ...provided,
          border:'2px solid black',
          borderRadius:'25px',
          color: state.isSelected ? 'purple' : 'black',
          padding: 20,
          width: 200,
        }),
        control: () => ({
          // none of react-select's styles are passed to <Control />
          width: 200,
          border: '2px solid black',
          borderRadius: '28px',
          textAlign:'center'
        }),
        singleValue: (provided, state) => {
          const opacity = state.isDisabled ? 0.5 : 1;
          const transition = 'opacity 300ms';
      
          return { ...provided, opacity, transition };
        }
      }
  
    const navigate = useNavigate();
    
    const goToLogin = () => {
        navigate('/login')
    }

    // שינוי תצוגת שדה הקליטה בעט לחיצה
    const [name, setName] = useState('');
    const handleChange = (event) => {
    setName(event.target.value);
    }
    
    let users = JSON.parse(localStorage.getItem('Users')); // יוזרס מקבל את מערך המשתמשים שנמצא בלוקאל סטורייג
    if (users == null) { // אם הלוקאל סטורייג ריק
        users = [{email:'admin@g.com', password:'12345'}]; // תוסיף את המשתמש של האדמין
    }

    // סטייטים לקילטת הפרמטרים מהשדות
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [userName, setUserName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPass, setConfirmPass] = useState('');
    const [country, setCountry] = useState({optionsCountryStr: optionsCountry[0]});
    const [city, setCity] = useState('');
    const [street, setStreet] = useState('');
    const [houseNumber, setHouseNumber] = useState('');
    const [cart, setCart] = useState([]);

    //סטייט למערך המשתמשים
    const [usersState, setUsersState] = useState(users);

    // פונקציה להוספת משתמש ללוקאל סטורייג
    const sendToLocalStorage = () => {
        console.log('email:' + email);
        console.log('password:' +password);
        setUsersState([...usersState,{firstName,lastName,userName,email,password,country,city,street,houseNumber,cart}])
        alert('thank you for sign up you can log in now')
    }

    useEffect(() => {
        localStorage.setItem('Users', JSON.stringify(usersState))
    }, [usersState])

    const validation = (event) => {
        event.preventDefault();

        if (Valid.validFirstName(firstName) === false) {
            alert(`first name can only contains letters in english `)
            return
        }

        if (Valid.validLastName(lastName) === false) {
            alert(`last name can only contains letters in english `)
            return
        }
    
        if (Valid.validUsername(userName) === false) {
            alert(`username can only contains letters in englis / numbers or special chars`)
            return
        }

        if((Valid.validatePassword(password)) === false){
            alert(`Password must contain at least one capital letter, one special char and one number`);
            return;
        }

        if (Valid.validMail(email) === false) {
            alert(`email must finished with ".com"`)
            return
        }

        if (Valid.validCity(city) === false) {
            alert(`email must finished with ".com"`)
            return
        }

        if(password !== confirmPass){
            alert('passwords doesnt match');
            return;
        }
        sendToLocalStorage();
    }

    return (
        <div style={{textAlign:'center', color:'white',fontFamily:'cursive', display:'flex', flexDirection:'column'}}>
            <h1>SignUp</h1>
            
                <Box component="form" sx={{ '& > :not(style)': { m: 1, width: '25ch' }, }} noValidate
                    autoComplete="off" bgcolor={'lightblue'} >


                    <TextField id="outlined-name" label ="First Name" onClick={handleChange}
                        onChange={e => setFirstName(e.target.value)} />

                    <br/>

                    <TextField id="outlined-uncontrolled" label="Last Name"
                        onChange={e => setLastName(e.target.value)} />

                    <br/>

                    <TextField id="outlined-name" label="userName"
                        onClick={handleChange} onChange={e => setUserName(e.target.value)} />

                    <br/>

                    <TextField id="outlined-uncontrolled" label="Email"
                        onChange={e => setEmail(e.target.value)} />

                    <br/>

                    <TextField id="outlined-uncontrolled" label="Password"
                        onChange={e => setPassword(e.target.value)} />

                    <br/>

                    <TextField id="outlined-name" label="confirm-password"onClick={handleChange}
                        onChange={e => setConfirmPass(e.target.value)} />

                    <br/>

                    <TextField id="outlined-uncontrolled" label="Country"
                        onChange={e => setCountry(e.target.value)} />

                    <br/>
                    
                    <TextField id="outlined-name" label="City"
                        onClick={handleChange} onChange={e => setCity(e.target.value)} />

                    <br/>

                    <TextField id="outlined-uncontrolled" label="Street"
                        onChange={e => setStreet(e.target.value)} />

                    <br/>

                    <TextField id="outlined-name" label="House Number"
                        onClick={handleChange} onChange={e => setHouseNumber(e.target.value)} />

                    <br/>
                    
                    <button onClick={validation} style={{marginTop:'30px',backgroundColor:'#03A586', cursor:'pointer',border:'2px solid black', borderRadius:'28px', padding:'9px 12px'}}><b>Sign Up</b></button>
                    <br/>
                    <button onClick={goToLogin} style={{marginTop:'30px',backgroundColor:'#03A586', cursor:'pointer',border:'2px solid black', borderRadius:'28px', padding:'9px 12px'}}><b>Already have an account?<br/>Go to Login</b></button>

                    
                    </Box>
                    
        </div>
       
    )
}
