import React, { useState } from 'react'
import ProductCard from '../Cards/ProductCard';

export default function Products() {

    let dataProd = JSON.parse(localStorage.getItem(`Products`)); // מקבל את מערך המוצרים מהלוקאל סטורייג
    const sessionUser = JSON.parse(sessionStorage.getItem(`login_user`)) || []; // מקבל את המשתמש שנמצא בסשן סטורייג
    const localUsers = JSON.parse(localStorage.getItem(`Users`)) || []; // מקבל את מערך כל המשתמשים מהלוקאל סטורייג
    let localUser = localUsers.filter(user => user.email === sessionUser.emailUser); // מקבל את פרטי המשתמש במחובר בסשן מהלוקאל סטורייג
    localUser = localUser[0]; // המרה לאובייקט
    
    const sendToMyCart = (id) => { // פונקציה להוספת מוצר לעגלה
        localUser.cart.push(id); // עדכון העגלה במספר המוצר בעגלה של המשתמש 
        let tempLocal = localUsers.filter(user => user.email !== sessionUser.emailUser) // מקבל את מערך המשתמשים ללא המשתמש שמוסיף לעגלה
        tempLocal.push(localUser) // דוחף לסוף מערך המשתמשים את המשתמש עם העגלה המעודכנת
        localStorage.setItem('Users' ,JSON.stringify(tempLocal)); // מעדכן את הלוקאל סטורייג במערך המשתמשים המעודכן
    }


    if (dataProd == null){ // אם מערך המוצרים בלוקאל סטורייג לא קיים
        dataProd = [{prod_id:'1',prod_name:'jbl flip 4',prod_img:"../ProductImages/jblFlip4.jpg",prod_desc:'waterproof and good sound',prod_price: 220 },
                    {prod_id:'2',prod_name:'jbl flip 3',prod_img:"../ProductImages/jblFlip3.jpg",prod_desc:'waterproof and good sound',prod_price:180 },
                    {prod_id:'3',prod_name:'jbl flip 5',prod_img:"../ProductImages/jblFlip5.jpg",prod_desc:'waterproof and good sound',prod_price:320},
                    {prod_id:'4',prod_name:'VoomBoox',prod_img:"../ProductImages/voomboox.jpg",prod_desc:'waterproof and good sound',prod_price:125},
                    {prod_id:'5',prod_name:'jbl Go 2',prod_img:"../ProductImages/jblGo2.jpg",prod_desc:'waterproof and good sound',prod_price:100 },
                    {prod_id:'6',prod_name:'jbl Go 3',prod_img:"../ProductImages/jblGo3.jpg",prod_desc:'waterproof and good sound',prod_price:130},
                    {prod_id:'7',prod_name:'pioneer',prod_img:"../ProductImages/pioneer.jpg",prod_desc:'waterproof and good sound',prod_price:100},
                ];
        localStorage.setItem('Products', JSON.stringify(dataProd)) // השם את מערך המוצרים בלוקאל סטורייג
    }

    let prodStr = dataProd.map((prod,index) => <ProductCard key = {index} id ={prod.prod_id} name = {prod.prod_name} img = {prod.prod_img}
         desc = {prod.prod_desc}  price = {prod.prod_price} sendToMyCart = {sendToMyCart} />) // משתנה להדפסת הכרטיסים של המוצרים

    return (
        <div style={{textAlign:'center', height:'100vh'}} >
            <br/>
            <label style={{fontFamily:'Cursive', fontSize:'35px',color:'white'}}> <b><u>Products Page</u></b></label>
            
            <div style={{display:'flex', flexDirection:'row', maxWidth:'80%' }}>
            
                {prodStr}

            </div>
             
        </div>
    )
}
