import React from 'react';
import { useEffect,useState } from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import { useNavigate } from 'react-router-dom';
import { textAlign } from '@mui/system';

export default function Login() {

    const navigate = useNavigate();

    const [name, setName] = useState('');
    const handleChange = (event) => {
    setName(event.target.value);
    }

    

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const loginUser = (event) => {
        event.preventDefault();
        let exist = false;
    
        let data = JSON.parse(localStorage.getItem(`Users`));

        if(data[0].emailUser === email && data[0].passUser === password){ // אם המשתמש שמנסה להתחבר זה האדמין
            let user = {emailUser:email, passUser:password}
            sessionStorage.setItem('login_user', JSON.stringify(user))
            exist = true;
        }

        for(let i = 0; i < data.length; i ++ ){ // אם המשתמש שמתחבר הוא אורח עובר על מערך המשתשים בלוקאל סטורייג
            if(data[i].email === email && data[i].password === password){
                let user = {emailUser:email, passUser:password}
                sessionStorage.setItem('login_user', JSON.stringify(user))
                exist = true;
            }
        }
        if(!exist){
            alert(`המשתמש לא נמצא במאגר`)
            return false
        }
        else{
            let userObj = {emailUser: email, passUser: password}
            navigate('/Profile', {state: userObj})
        }
    }

    return (
        <div style={{height:'83vh'}} >
           <div style={{textAlign:'center'}}>
               <br/>
           <label style={{fontFamily:'Cursive', fontSize:'35px',color:'white'}}> <b><u>login Page</u></b></label>
                <Box component="form" sx={{ '& > :not(style)': { m: 1, width: '25ch' },}} noValidate autoComplete="off"
                    bgcolor={'lightblue'} marginTop={'50px'}   border={'4px solid gray'} 
                    >
                    
                        <h2 style={{fontFamily:'Cursive', fontSize:'40px',color:'navy'}}> <b><u>Login Form</u></b></h2>

                        <br/>

                        <TextField id="outlined-name" label="Email"onClick={handleChange} 
                                    onChange={e => setEmail(e.target.value)} />
                        <br/>

                        <TextField id="outlined-uncontrolled" label="Password"
                            onChange={e => setPassword(e.target.value)} />

                        <br/>

                        <button onClick={loginUser} style={{marginTop:'30px',backgroundColor:'#03A586', cursor:'pointer',border:'2px solid black',
                                    borderRadius:'28px', padding:'9px 12px'}}><b>Login</b></button>
                    
                    

                </Box>
                    
            </div>
        </div>
    )
}
