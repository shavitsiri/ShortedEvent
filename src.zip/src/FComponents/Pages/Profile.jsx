import React from 'react';
import UserCard from '../Cards/UserCard';
import ProfileNoExist from '../Cards/ProfileNoExist';
import AdminCard from '../Cards/AdminCard';
import { useNavigate } from 'react-router-dom';



export default function Profile() {

    const navigate = useNavigate();

    const goToSignUp = () => {
        navigate("/SignUp")
    }

    const goToLogin = () => {
        navigate("/Login")
    }
       
    

    let sessionUser = JSON.parse(sessionStorage.getItem(`login_user`)); // מקבל את המשתמש המחובר
    let userDetails = JSON.parse(localStorage.getItem(`Users`)); // מקבל את מערך המשתמשים מהלוקאל סטורייג

    //משתנים להצגת הפרופיל
    let firstNameProf = "";
    let lastNameProf = "";
    let userNameProf = "";
    let emailProf = "";
    let countryProf = "";
    let cityProf = "";
    let streetProf = "";
    let houseNumberProf = "";
    let profileCard;
    
    
    if(sessionUser !== null){ // 
        if(sessionUser.emailUser === 'admin@g.com'){ // אם המשתמש הוא האדמין
            firstNameProf = "Admin";
            lastNameProf = "admin";
            emailProf = 'admin@g.com';
            profileCard = <AdminCard/>
        }
        else{
            for(let i = 1; i < userDetails.length; i++){ // 
                if(userDetails[i].email === sessionUser.emailUser){
                     firstNameProf = userDetails[i].firstName;
                     lastNameProf = userDetails[i].lastName;
                     userNameProf = userDetails[i].userName;
                     emailProf = userDetails[i].email;
                     countryProf =  userDetails[i].country;
                     cityProf = userDetails[i].city;
                     streetProf = userDetails[i].street;
                     houseNumberProf = userDetails[i].houseNumber;

                     profileCard = <UserCard firstName = {firstNameProf} lastName = {lastNameProf}  userName = {userNameProf}
                        email = {emailProf} country = {countryProf} city = {cityProf} street = {streetProf} houseNumber = {houseNumberProf} />
                }
            } 
        } 
    }

    if(sessionUser === null){
        profileCard = <ProfileNoExist goToLogin = {goToLogin} goToSignUp = {goToSignUp}/>
    }

   
   

    

    return (
        <div style={{display:'flex', flexDirection:'column', alignItems:'center',height:'83vh'}}>

            <br/>

            <label style={{fontFamily:'Cursive', fontSize:'35px',color:'white'}}> <b><u>Profile Page</u></b></label>
            
            <br/>

                {profileCard}

        </div>
    )
}
