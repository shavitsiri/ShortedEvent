import React from 'react'
import { useNavigate } from 'react-router-dom';
import ProductCard from '../Cards/ProductCard';

export default function Home() {

    const navigate = useNavigate();

    const goToProductPage = () => {
        navigate('/Products')
    }

    const sessionUser = JSON.parse(sessionStorage.getItem(`login_user`)) || []; // מקבל את המשתמש שנמצא בסשן סטורייג
    const localUsers = JSON.parse(localStorage.getItem(`Users`)) || []; // מקבל את מערך כל המשתמשים מהלוקאל סטורייג
    let localUser = localUsers.filter(user => user.email === sessionUser.emailUser); // מקבל את פרטי המשתמש במחובר בסשן מהלוקאל סטורייג
    localUser = localUser[0]; // המרה לאובייקט
    
    const sendToMyCart = (id) => { // פונקציה להוספת מוצר לעגלה
        localUser.cart.push(id); // עדכון העגלה במספר המוצר בעגלה של המשתמש 
        let tempLocal = localUsers.filter(user => user.email !== sessionUser.emailUser) // מקבל את מערך המשתמשים ללא המשתמש שמוסיף לעגלה
        tempLocal.push(localUser) // דוחף לסוף מערך המשתמשים את המשתמש עם העגלה המעודכנת
        localStorage.setItem('Users' ,JSON.stringify(tempLocal)); // מעדכן את הלוקאל סטורייג במערך המשתמשים המעודכן
    }




        let products =   JSON.parse(localStorage.getItem(`Products`)) || []; 
        let recomndedProds = products.filter(prod => prod.prod_id !== '1' && prod.prod_id !== '2' && prod.prod_id !== '4' && prod.prod_id !== '6' )
        console.log(recomndedProds);

        let recomdedStr = recomndedProds.map(( prod) => <ProductCard  key = {prod.prod_id} id ={prod.prod_id} name = {prod.prod_name} img = {prod.prod_img} desc = {prod.prod_desc}  price = {prod.prod_price} sendToMyCart = {sendToMyCart} />)
        
        let bestDeals = products.filter(prod => prod.prod_id !== '3' && prod.prod_id !== '2' && prod.prod_id !== '7' && prod.prod_id !== '6' )

        let bestDealsStr = bestDeals.map(( prod) => <ProductCard  key = {prod.prod_id} id ={prod.prod_id} name = {prod.prod_name} img = {prod.prod_img} desc = {prod.prod_desc}  price = {prod.prod_price} sendToMyCart = {sendToMyCart} />)


    return (
        <div style={{display:'flex',flexDirection:'column'}}>

            <br/>

            <label style={{fontFamily:'Cursive', fontSize:'35px',color:'white',textAlign:'center', alignItems:'center'}}> <b><u>Welcome To Electrify</u></b></label>
            
            <div style={{border:'2px solid purple' ,borderRadius:'25px', padding:'25px', margin:'30px'}}>
                
                <div >
                <label style={{fontFamily:'Cursive', fontSize:'35px',color:'pink'}}> <b><u>Recomnded products:</u></b></label>  
                </div>

                <div style={{display:'flex' , flexDirection:'row', }}>
                    {recomdedStr}
                </div>

                <div>
                <button onClick={goToProductPage} style={{marginTop:'30px',backgroundColor:'#03A586', cursor:'pointer',border:'2px solid black',
                                 borderRadius:'28px', padding:'9px 12px', float:'right'}}><b>Go to all products</b></button>
                </div>

            </div>

            <div style={{border:'2px solid purple' ,borderRadius:'25px', padding:'25px', margin:'30px'}}>
                
                <div >
                <label style={{fontFamily:'Cursive', fontSize:'35px',color:'pink'}}> <b><u>Best deals:</u></b></label>
                </div>

                <div style={{display:'flex' , flexDirection:'row', }}>
                    {bestDealsStr}
                </div>

                <div>
                <button onClick={goToProductPage} style={{marginTop:'30px',backgroundColor:'#03A586', cursor:'pointer',border:'2px solid black',
                                 borderRadius:'28px', padding:'9px 12px', float:'right'}}><b>Go to all products</b></button>
                </div>

            </div>
            

        </div>
    )
}
