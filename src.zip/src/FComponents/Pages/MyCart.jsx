import React from 'react';
import { useState } from 'react';
import ProductInCart from '../Cards/ProductInCart';

export default function MyCart(props) {

    const sessionUser = JSON.parse(sessionStorage.getItem(`login_user`)) || []; // מקבל את המשתמש שנמצא בלוקאל סטורייג
    const products = JSON.parse(localStorage.getItem(`Products`)) || []; // מקבל את מערך כל המוצרים מהלוקאל סטורייג
    const localUsers = JSON.parse(localStorage.getItem(`Users`)) || [];  // מקבל את מערך כל המשתמשים מהלוקאל סרטוייג
    let localUser = localUsers.filter(user => user.email === sessionUser.emailUser) // מקבל את כל פרטי המשתמש המחובר מהלוקאל סטורייג
    localUser = localUser[0]; // המרה לאובייקט
    let cartStr = []; // מערך מוצרים זמני
    let sumOfCart = 0;
    let renderCart;

  


    const deleteFromCart = (id) => {
        console.log("id: " + id);
       
    }


    if(sessionUser.emailUser !== undefined){ // אם קיים משתמש מחובר
        for(let i=0,j=0; i < products.length; i++){ // ללולאה שעוברת על כל המוצרים בלוקאל סטורייג
            for(let j = 0; j < localUser.cart.length; j ++){ // מעבר על אורך העגלה של המשתמש המחובר
                if(localUser.cart[j] === products[i].prod_id){ // אם המספר מוצר בלוקאל שווה למוצר לוקאל בעגלה
                    j++;
                    let prod_id = products[i].prod_id;
                    let prod_name = products[i].prod_name;
                    let prod_img = products[i].prod_img;
                    let prod_desc = products[i].prod_desc;
                    let prod_price = products[i].prod_price;
                    cartStr.push({id:prod_id,name:prod_name,img:prod_img,desc:prod_desc
                                     ,price:prod_price}); // דחיפת המוצר ופרטיו למערך המוצרים הזמני
                    sumOfCart += prod_price;
                    break;
                }
            }
        }
    renderCart = cartStr.map((prod) => <ProductInCart  key = {prod.id} id ={prod.id} name = {prod.name}
                 img = {prod.img} desc = {prod.desc}  price = {prod.price} deleteFromCart = {deleteFromCart}/>) // מקבל את מערך המוצרים הזמני בתוך הכרטיסים

    }

    
    
        


    


    return (
        <div style={{height:'100vh', textAlign:'center'}} >

            <label style={{fontFamily:'Cursive', fontSize:'35px',color:'white'}}> <b><u>MyCart Page</u></b></label>

            <br/>
                
            <div  style={{display:'flex', flexDirection:'row', maxWidth:'80%' }} >
                {renderCart}
            </div>

            <div>

            <label style={{fontFamily:'Cursive', fontSize:'35px',color:'yellow'}}> <b><u>sum : {sumOfCart} ₪ </u></b></label>
                
            </div>

        </div>
    )
}
