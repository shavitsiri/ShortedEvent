
     export function validatePassword(password) {
        let user_password = password;
        var counterup = 0;
        var countchar = 0;
        var countnumber = 0;
        for (let i = 0; i < user_password.length; i++) {
            if (user_password[i] >= 'A' && user_password[i] <= 'Z') {
                counterup = 1;
            }
            var specialChars = "<>@!#$%^&*()_+[]{}?:;|'\"\\,./~`-=";
            for (let j = 0; j < specialChars.length && countchar !== 1; j++) {
                if (user_password[i] === specialChars[j]) {
                    countchar = 1;
                }
            }
            var numbers = "0123456789"
            for (let h = 0; h < numbers.length && countnumber !== 1; h++) {
                if (user_password[i] === numbers[h]) {
                    countnumber = 1;
                }
            }
            if (counterup === 1 && countchar === 1 && countnumber === 1) {
                return true;
            }
        }
        return false;
    }


    export function validMail (email) {// פונצקיה לבדיקת התאמות מייל
       
        let user_email = email;
        let i = user_email.length - 4;
        if (user_email[i] === '.' && user_email[i + 1] === 'c' && user_email[i + 2] === 'o' && user_email[i + 3] === 'm') {
            return true;
        }
        return false;
    }


    export function  validUsername (userName) { // פונקציה לבדיקת היוזרניים
        for (let i = 0; i < userName.length; i++) {
            if (!(userName[i] >= '!' && userName[i] <= 'z')) {
                return false
            }
        }
        return true;
    }

    export function validFirstName (firstName)  {// פונקציה לבדיקת השם הפרטי
        let first_name = firstName;
        console.log(firstName)
        for (let i = 0; i < first_name.length; i++) {
            if (!(first_name[i] >= 'A' && first_name[i] <= 'Z' || first_name[i] >= 'a' && first_name[i] <= 'z')) {
                return false;
            }
        }
        return true;
    }


    export function validLastName (lastName)  { // פונקציה לבדיקת השם משפחה
        let last_name = lastName;
        for (let i = 0; i < last_name.length; i++) {
            if (!(last_name[i] >= 'A' && last_name[i] <= 'Z' || last_name[i] >= 'a' && last_name[i] <= 'z')) {
                return false;
                }
            }
        return true;
        }

    export function validCity (city) { // פונקציה לבדיקת השם משפחה
        for (let i = 0; i < city.length; i++) {
            if (!(city[i] >= 'A' && city[i] <= 'Z' || city[i] >= 'a' && city[i] <= 'z')) {
                return false;
                }
            }
        return true;
    }

    








